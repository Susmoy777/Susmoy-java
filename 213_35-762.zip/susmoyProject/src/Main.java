import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.println("1.Local user\n 2.ticket counter employee");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Select an option:");
        int c = scanner.nextInt();
        LoacalUser l1 = new LoacalUser();
        if(c==1){
            l1.UserInfo();
        }
        else if(c==2)
        {
           CounterEmployee c3 = new CounterEmployee();
            c3.E_info();
        }
    }
}