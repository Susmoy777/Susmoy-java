public class E_Logininfo extends LoginInfo{
    private  String E_ID;

    public String getE_ID() {
        return E_ID;
    }
    public void setE_ID(String e_ID) {
        E_ID = e_ID;
    }
}
