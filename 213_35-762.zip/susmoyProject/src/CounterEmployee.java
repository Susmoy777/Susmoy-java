import java.util.Scanner;
public class CounterEmployee{
    void E_info() {
        while (true) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter employee userId:");
            String Eid = sc.nextLine();
            System.out.println("Enter employee pass password : ");
            String E_pass = sc.nextLine();
            E_Logininfo e1 = new E_Logininfo();
            e1.setE_ID("762");
            e1.setUpass("susmoy");
            String a1 = e1.getE_ID();
            String b1 = e1.getUpass();
            int m = a1.compareTo(Eid);
            int n = b1.compareTo(E_pass);
            if (m== 0 || n == 0) {
                System.out.println("-----------Employee login successfully done-------------");
                System.out.println("___________________Welcome to Bangladesh MetroRail _____________________");
                System.out.println("1.Ticket booked confarmation");
                System.out.println("2.view Time Sheduling");
                System.out.println("3.Exit");

                System.out.println("Choice?");



            }
            else
            {
                System.out.println("Worng pass!!!! try again ");
            }

         }
       }
    }
