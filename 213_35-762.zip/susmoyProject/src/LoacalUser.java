import java.util.Scanner;
public class LoacalUser {
    void UserInfo() {
        while (true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter your username:");
            String Uname = scanner.nextLine();
            System.out.println("Enter your password :");
            String Upass = scanner.nextLine();
            LoginInfo l2 = new LoginInfo();
            l2.setUname("s");
            l2.setUpass("2");
            String un = l2.getUname();
            String ps = l2.getUpass();
            int x = un.compareTo(Uname);
            int y = ps.compareTo(Upass);
            if (x == 0 && y == 0) {
                System.out.println("Login Successfully");
                System.out.println("___________________Welcome to Bangladesh MetroRail _____________________");
                while (true) {
                    System.out.println("1.view available stations and routes\n");
                    System.out.println("2.select a route and purchase tickets\n");
                    System.out.println("3.cancel ticket");
                    System.out.println("4.Help Line");
                    System.out.println("5.EXIT");
                    System.out.println("Enter You Choice :");
                    int choice = scanner.nextInt();
                    if (choice == 1) {

                    } else if (choice == 2) {
                        break;
                    } else {
                        System.out.println("Worng pass!try again");
                    }
                }
            }
        }
    }
}
